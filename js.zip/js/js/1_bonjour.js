

var prenom = String(prompt("Veuillez saisir votre prenom")), 
    nom = String(prompt("Veuillez saisir votre nom"));

console.log(prenom + nom);
var resultat = "Bonjour " + prenom + " " + nom;

alert(resultat);

